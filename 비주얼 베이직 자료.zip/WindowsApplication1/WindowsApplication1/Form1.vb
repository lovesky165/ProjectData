﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim su1, su2, sum As Integer
        su1 = TextBox1.Text
        su2 = TextBox2.Text
        sum = su1 + su2
        TextBox3.Text = su1 + su2
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim su1, su2, min As Integer
        su1 = TextBox1.Text
        su2 = TextBox2.Text
        min = su1 - su2
        TextBox3.Text = su1 - su2
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim su1 As Byte
        Dim su2 As Long
        su1 = TextBox1.Text
        su2 = TextBox2.Text
        TextBox3.Text = su1 * su2
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim su1 As Byte
        Dim su2 As Long
        su1 = TextBox1.Text
        su2 = TextBox2.Text
        TextBox3.Text = su1 / su2
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
