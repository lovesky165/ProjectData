﻿Public Class Form1
    Dim a, b, c
    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        a += 1
        If a > ProgressBar1.Maximum Then
            MessageBox.Show("데드풀2 매진되었습니다")
            a = ProgressBar1.Maximum
        End If
        ProgressBar1.Value = a
        TextBox1.Text = a & "/" & ProgressBar1.Maximum
    End Sub

    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox2.Click
        b += 1
        If b > ProgressBar2.Maximum Then
            MessageBox.Show("어벤져스 앤드게임 매진되었습니다")
            b = ProgressBar2.Maximum
        End If
        ProgressBar2.Value = b
        TextBox2.Text = b & "/" & ProgressBar2.Maximum
    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        c += 1
        If c > ProgressBar3.Maximum Then
            MessageBox.Show("베놈 매진되었습니다")
            c = ProgressBar3.Maximum
        End If
        ProgressBar3.Value = c
        TextBox3.Text = c & "/" & ProgressBar3.Maximum
    End Sub
End Class
