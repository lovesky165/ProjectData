﻿Public Class Form1
    Dim Lotto(6), a(6), b(6), c(6), d(6), f(6) As Integer
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim i As Integer
        Randomize()
        For i = LBound(Lotto) To UBound(Lotto)
            Lotto(i) = Int(Rnd() * 45) + 1
            If i > 1 Then
                For j = 1 To -1
                    If Lotto(i) = Lotto(j) Then
                        i = i - 1
                    End If
                Next j
            End If
        Next i
        For i = LBound(a) To UBound(a)
            a(i) = Int(Rnd() * 45) + 1
            If i > 1 Then
                For j = 1 To -1
                    If a(i) = a(j) Then
                        i = i - 1
                    End If
                Next j
            End If
        Next i
        For i = LBound(b) To UBound(b)
            b(i) = Int(Rnd() * 45) + 1
            If i > 1 Then
                For j = 1 To -1
                    If b(i) = b(j) Then
                        i = i - 1
                    End If
                Next j
            End If
        Next i
        For i = LBound(c) To UBound(c)
            c(i) = Int(Rnd() * 45) + 1
            If i > 1 Then
                For j = 1 To -1
                    If c(i) = c(j) Then
                        i = i - 1
                    End If
                Next j
            End If
        Next i
        For i = LBound(d) To UBound(d)
            d(i) = Int(Rnd() * 45) + 1
            If i > 1 Then
                For j = 1 To -1
                    If d(i) = d(j) Then
                        i = i - 1
                    End If
                Next j
            End If
        Next i
        For i = LBound(f) To UBound(f)
            f(i) = Int(Rnd() * 45) + 1
            If i > 1 Then
                For j = 1 To -1
                    If f(i) = f(j) Then
                        i = i - 1
                    End If
                Next j
            End If
        Next i

        TextBox1.Text = Lotto(6)
        TextBox2.Text = a(6)
        TextBox3.Text = b(6)
        TextBox4.Text = c(6)
        TextBox5.Text = d(6)
        TextBox6.Text = f(6)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class
